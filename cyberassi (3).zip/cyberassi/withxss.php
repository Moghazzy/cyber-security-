<?php
session_start();
require 'config.php';

// Redirect to login page every time grades.php is accessed
if (!isset($_SESSION['grades_logged_in']) || !$_SESSION['grades_logged_in']) {
    header('Location: login.php');
    exit;
}

// Fetch the grades for the logged-in user
$stmt = $pdo->prepare('SELECT * FROM grades WHERE user_id = ?');
$stmt->execute([$_SESSION['user_id']]);
$grades = $stmt->fetchAll();

// Unset grades_logged_in session variable to force login on next access
unset($_SESSION['grades_logged_in']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Your Grades</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .list-group-item {
            border: none;
            border-bottom: 1px solid #ddd;
        }
        .btn-custom {
            margin: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h1 class="text-center">Your Grades</h1>
                <ul class="list-group mt-4">
                    <?php foreach ($grades as $grade): ?>
                        <li class="list-group-item">
                            <strong><?php echo htmlspecialchars($grade['course'], ENT_QUOTES, 'UTF-8'); ?>:</strong> 
                            <?php echo htmlspecialchars($grade['grade'], ENT_QUOTES, 'UTF-8'); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <div class="mt-4 text-center">
                    <a href="upload.php" class="btn btn-primary btn-custom">Upload Assignment</a>
                    <a href="change_pass.php" class="btn btn-secondary btn-custom">Change Password</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrap.com/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
