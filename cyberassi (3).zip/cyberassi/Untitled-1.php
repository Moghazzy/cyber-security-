<?php
// Array of users with their respective plain passwords
$users = [
    ['username' => 'moghazy', 'password' => 'moghazy12'],
    ['username' => 'farag', 'password' => 'farag12'],
    ['username' => 'eyad', 'password' => 'eyad12']
];

foreach ($users as $user) {
    $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);
    echo "Username: " . htmlspecialchars($user['username']) . "<br>";
    echo "Original password: " . htmlspecialchars($user['password']) . "<br>";
    echo "Hashed password: " . htmlspecialchars($hashed_password) . "<br><br>";
}
?>
