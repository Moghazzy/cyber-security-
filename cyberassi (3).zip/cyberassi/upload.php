<?php
session_start();
require 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Check the number of current assignments
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM assignments WHERE user_id = ?');
        $stmt->execute([$_SESSION['user_id']]);
        $assignment_count = $stmt->fetchColumn();

        if ($assignment_count >= 5) {
            $message = "You have already uploaded the maximum number of assignments.";
        } else {
            $target_dir = "uploads/";

            // Create the uploads directory if it doesn't exist
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            $total_files = count($_FILES['filesToUpload']['name']);
            $upload_count = 0;

            for ($i = 0; $i < $total_files; $i++) {
                if ($assignment_count + $upload_count >= 5) {
                    break; // Stop uploading if the limit is reached
                }

                $filename = basename($_FILES["filesToUpload"]["name"][$i]);
                $target_file = $target_dir . $filename;
                $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                // Check file type (allow only certain file types)
                $allowed_types = ['jpg', 'png', 'pdf', 'doc', 'docx'];
                if (!in_array($file_type, $allowed_types)) {
                    continue; // Skip disallowed file types
                }

                // Move uploaded file to target directory
                if (move_uploaded_file($_FILES["filesToUpload"]["tmp_name"][$i], $target_file)) {
                    $stmt = $pdo->prepare('INSERT INTO assignments (user_id, filename, filepath) VALUES (?, ?, ?)');
                    $stmt->execute([$_SESSION['user_id'], $filename, $target_file]);
                    $upload_count++;
                }
            }

            if ($upload_count > 0) {
                $message = "$upload_count file(s) uploaded successfully.";
            } else {
                $message = "No files were uploaded.";
            }
        }
    } catch (Exception $e) {
        $message = "An error occurred: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Upload Assignments</title>
</head>
<body>
<div class="container">
    <h1 class="mt-5">Upload Assignments</h1>
    <?php if ($message): ?>
        <div class="alert alert-<?php echo strpos($message, 'error') !== false ? 'danger' : 'success'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="filesToUpload">Select files to upload (max 5):</label>
            <input type="file" name="filesToUpload[]" class="form-control-file" id="filesToUpload" multiple>
        </div>
        <button type="submit" class="btn btn-primary">Upload Files</button>
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
