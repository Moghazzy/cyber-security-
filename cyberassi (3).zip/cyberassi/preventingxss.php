<?php
session_start();
require 'config.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login2.php');
    exit;
}

// Validate session user_id to be an integer
$user_id = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
if ($user_id === false) {
    // Invalid user_id, force logout
    header('Location: logout.php');
    exit;
}

try {
    $stmt = $pdo->prepare('SELECT * FROM grades WHERE user_id = ?');
    $stmt->execute([$user_id]);
    $grades = $stmt->fetchAll();
} catch (Exception $e) {
    // Handle exception (log error, show user-friendly message, etc.)
    $grades = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Your Grades</title>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="text-center">Your Grades</h1>
            <?php if (empty($grades)): ?>
                <div class="alert alert-warning text-center">
                    No grades available.
                </div>
            <?php else: ?>
                <ul class="list-group mt-4">
                    <?php foreach ($grades as $grade): ?>
                        <li class="list-group-item">
                            <strong><?php echo htmlspecialchars($grade['course'], ENT_QUOTES, 'UTF-8'); ?>:</strong> 
                            <?php echo htmlspecialchars($grade['grade'], ENT_QUOTES, 'UTF-8'); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <div class="mt-4 text-center">
                <a href="upload.php" class="btn btn-primary">Upload Assignment</a>
                <a href="change_password.php" class="btn btn-secondary">Change Password</a>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
